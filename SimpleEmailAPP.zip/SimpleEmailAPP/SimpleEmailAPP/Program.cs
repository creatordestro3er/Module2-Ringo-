﻿// See https://aka.ms/new-console-template for more information
using System;
using System.Net.Mail;


namespace SimpleEmailAPP
{
    internal class Program {
        static void Main(string[] args)
        {
            try
            {
                MailMessage mail = new MailMessage();
                SmtpClient smpt = new SmtpClient("smtp.gmail.com");

                mail.From = new MailAddress("vinaynainwal005@gmail.com");
                mail.To.Add("vinaynainwal5@gmail.com");
                mail.Subject = "Reminder";
                mail.Body = "this is test message to fill your from ";

                smpt.Port = 587;
                smpt.Credentials = new System.Net.NetworkCredential("vinaynainwal005@gmail.com", "your Acess Password");
                smpt.EnableSsl = true;

                smpt.Send(mail);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            
        }
    }
  
}



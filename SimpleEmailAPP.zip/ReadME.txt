Module 2
add your password in the section of your password to start email functionality